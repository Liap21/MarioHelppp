package com.tutorial.mario;

public enum Id {
    player, wall, mushroom, goomba, powerUp, pipe, coin, towerBoss, koopa, flag, plant, star, trail, particle;

}
