package com.tutorial.mario.states;

public enum KoopaStates {
    WALKING, SHELL, SPINNING
}
