package com.tutorial.mario.states;

public enum PlayerState {
    BIG, SMALL, DEAD
}
