package com.tutorial.mario.states;

public enum BossState {
    IDLE, SPINNING, JUMPING, RUNNING, RECOVERING
}
